Stream_t *OpenScsi(struct device *dev,
		   const char *name, int mode, char *errmsg,
		   int mode2, int locked, int lockMode,
		   mt_off_t *maxSize);

